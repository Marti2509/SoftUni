﻿using System;

namespace AuthorProblem
{

    [Author("Victor")]
    public class StartUp
    {
        [Author("George")]
        [Author("Pesho")]
        public static void Main(string[] args)
        {

        }
    }
}
