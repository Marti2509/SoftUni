﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Person
{
    public class Child : Person
    {
        public Child(string name, uint age)
            : base(name, age)
        {

        }
    }
}
